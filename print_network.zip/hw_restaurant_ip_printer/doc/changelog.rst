.. _changelog:

Changelog
=========


`Version 0.1.0 (Thu Nov 5 04:40:42 2020 +0300)
-------------------------------------------------
- Initial Release for Odoo 14.0

