.. _changelog:

Changelog
=========

`Version 0.1.0 (Thu Nov  5 03:41:35 2020)`
--------------------------------------------
- Initial Release for Odoo 14.0

